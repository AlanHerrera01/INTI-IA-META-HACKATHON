INTI Windows agent - Python 3.12+ required.
Extract into a folder owned by your Windows user.
Run PowerShell: powershell -ExecutionPolicy Bypass -File .\Start-INTI-Agent.ps1
For a remote server add -Backend https://your-server.example (HTTPS required).
Create a one-use pairing code in INTI and enter it in the agent console.
Only workspace/<task-id>/<name>.txt can be created; no overwrite or arbitrary shell commands.
Compatible desktop applications are detected and need explicit operator permission plus exact task approval.
Application launches use a detected executable without arguments; this does not control its contents.
The local credential in .local must remain private. Never share .local or .venv.
Review the device folder, text and URL in INTI before approving each task.
Ctrl+C stops the agent; earlier files and windows remain.
This release requests Windows Notepad/browser launches; visual app completion is not certified.
Mac/Linux and unrestricted desktop control are not supported in this release.
