"""INTI architecture package."""
